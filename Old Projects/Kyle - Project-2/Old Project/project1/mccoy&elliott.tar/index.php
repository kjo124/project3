<?php
include 'header.php';
include 'nav.php';


?>
	<body>
		
	<!-- create three coulumn with lg and md size-->
		
		<div class="container-fluid">
			<div class="row visible-on">
                            <div class="col-md-4">
                                <img src="tumeric2.jpg" class="img" alt="tumeric" width="250" height="200"></img>
                                <img src="kohlrabi.jpg" class="img" alt="kohlrabi" width="250" height="200"></img>
                                <img src="cilantro.jpg" class="img" alt="cilantro" width="250" height="200"></img>
                            </div>
            
					
					
					
					
					
					
					
	<!-- Add Main Content here -->
                <div class="col-lg-5">
                        <div class="Title">
                        <h1>Welcome! Learn all about ingredients</h1> 
                        </div>
                        <div class="maincontent">    
                        <p> Welcome to our homepage! This site is so you can learn about three ingredients: Kohlrabi, Tumeric, and Cilantro. The about us link will take you to our page where you can learn all about the owners. If you use the drop down menu you will find links to our pages for each ingredient. If you log in you will beable to make comments on our ingredient pages. All photos used are open source and from <a href=https://pixabay.com/>pixabay.com</a> and <a href=https://www.pexels.com/>pexels.com</a>.</p>
                      
                        </div>	
                </div>
		</div>
		</div>
<?php
include 'footer.php';
?>

	</body>
</html>
